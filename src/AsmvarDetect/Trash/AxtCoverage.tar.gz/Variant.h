/* Author : Shujia Huang
 * Date   : 2013-10-2
 *
 * This is the header of Variant.cpp
 *
 */
#ifndef _VARIANT_H
#define _VARIANT_H

#include <vector>
#include <map>
#include "Axt.h"
#include "Region.h"

class VarUnit { // Well, it looks like the class 'Axt', but no! Totally different! Use for record the varants.

public:
	Region target; // target or said reference
	Region query;  // the mapping one

	string tarSeq; // Not yet
	string qrySeq; // not yet, if include this part we should consider the coversion coordinate problem, so that to make me get the right seq
	char  strand;
	string type;
	
	VarUnit () : tarSeq( "-" ), qrySeq( "-" ) {}

	void OutErr () { // Output the axt alignment to STDERR
        cerr<< target.id << "\t" << target.start << "\t" << target.end << "\t"
            << query.id  << "\t" << query.start  << "\t" << query.end  << "\n"
            << tarSeq    << "\n" << qrySeq       << endl;
    }
};

class MapReg { // Mapping regions

public:
	Region target; // target or said reference
	Region query;  // the mapping one
	char  strand;  // Mapping strand
}

class AxtVar : public Axt {

private: 
	vector< VarUnit > insertion;     //
	vector< VarUnit > deletion;      //
	vector< VarUnit > inversion;     //
	vector< VarUnit > translocation; //
	vector< VarUnit > simulreg;      // simultaneous gap regions
	vector< VarUnit > nosolution;

	map< string, vector<MapReg> > mapreg; // Mapping region. use for getting novel region
	map< string, vector<Region> > mapqry; // query's mapping regions

	// Make 'CallIversion' function to be private, because this function can only be call when all
	// the alignment have been read in 'mapreg'.
	void CallIversion   ( MapReg left, MapReg middle, MapReg right );
	void CallNoSolution ( MapReg mapreg );
public : 

	AxtVar () : insertion.clear(), deletion.clear(), mapreg.clear() {}

public :
	void CallInsertion ();
	void CallDeletion  ();
	void CallMapRegVar (); //simultaneous gaps, Inversion, translocation and no solution region 

	// Use for get the gap region, which actually would be the indel regions. can call deletion or insertion
	friend map< size_t, vector<size_t> > MakeClust ( vector<MapReg> & mapreg );
	friend unsigned int ClustLength ( vector<MapReg> & mapreg, vector<size_t> index );
	friend vector< VarUnit > CallGap ( Region & tar, string & tarSeq, Region & qry, string & qrySeq, string type );
	friend VarUnit CallGap ( MapReg left, MapReg right, string type ); // call simultaneous gaps.
	friend inline bool MySortByTar ( MapReg i, MapReg j );
	friend inline bool MySortByQry ( MapReg i, MapReg j );
};

#endif

