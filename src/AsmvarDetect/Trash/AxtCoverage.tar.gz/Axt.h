/* 
 * Author : Shujia Huang
 * Date   : 2013-10-2
 *
 * This is the header of API use for parse the *.axt file. 
 *
 */

#ifndef _AXTVAR_H
#define _AXTVAR_H

#include <iostream>
#include <string>
#include "Region.h"

using namespace std;

class Axt {
/*
1 chrM 16308 16389 Contig102837 1 81 + 5938
CATAGTACATAAAGTCATTTACCGTACATAGCACATTACAGTCAAATCCCTTCTCGTCCCCATGGATGACCCCCCTCAGATA
CATAGCACATATAGTCATTCATCGTACATAGCACATTATAGTCAAATCATTTCTCGTCCCCACGGAT-ATCCCCCTCAGATA

*/
public:
	int id;        // 1
    Region target; // chrM 16308 16389
    Region query;  // Contig102837 1 81
    char strand;   // +
    long score;    // 5938
    string tarSeq; // CATAGTACATAAAGTCATTTACCGTACATAGCACATTACAG (target sequence)
    string qrySeq; // CATAGCACATATAGTCATTCATCGTACATAGCACATTATAG (query  sequence)

private: 
	void err(string reason) {
        cerr<<"Error on ID: "<< id <<" ("<< target.id <<"<-"<< query.id <<")\n";
        cerr<<"Reason: "     << reason   << endl;
		if ( SeqLength() > 100 ) { // Keep the output sequence is not too long!
			tarSeq = tarSeq.substr( 0, 100 ) + " ... "; 
			qrySeq = qrySeq.substr( 0, 100 ) + " ... ";
		}
		OutErrAlg ();
        exit(EXIT_FAILURE);
    }

public:
	void CheckAxt() {
		if ( tarSeq.length() != qrySeq.length() ) err ( "tarSeq.length() != qrySeq.length()" );
		if ( tarSeq.empty()  || qrySeq.empty()  ) err ( "tarSeq.empty()  || qrySeq.empty()"  );
		if ( strand != '+' && strand != '-'     ) err ( "strand != '+' && strand != '-'"     );
		if ( target.id.empty() || query.id.empty() ) err ( "target.id.empty() || query.id.empty()" );
		if ( target.start <= 0 || target.end <= 0 || query.start <= 0 || query.end <= 0 ) 
			err ( "target.start <= 0 || target.end <= 0 || query.start <= 0 || query.end <= 0" );
	}
	void OutErrAlg () { // Output the axt alignment to STDERR
		cerr<< "#" << id << target.id << "\t" << target.start << "\t" << target.end << "\t"
        	<< query.id  << "\t" << query.start << "\t" << query.end  << "\n"
         	<< tarSeq    << "\n" << qrySeq      << endl;
	}

	void RmGap2Gap () { // Remove the gap to gap base into the algnment. it may calls by lastz's bug!
	// debug carefully here!!
		for ( string::iterator itt( tarSeq.begin() ), itq( qrySeq.begin() ); itt != tarSeq.end(); ) {
			if ( *itt == '-' && *itq == '-' ) {
//cerr << tarSeq << "\t" << qrySeq << endl;
				itt = tarSeq.erase( itt );
				itq = qrySeq.erase( itq );
//cerr << tarSeq << "\t" << qrySeq << endl;
			} else {
				++itt; ++itq;
			}
		}
	}
	unsigned int SeqLength () { return tarSeq.length(); }

	void ConvQryCoordinate ( unsigned int length ) {
	// This funtion just conversion the coordinate but not conversion the query sequence, 
	// which would be a problem when consider the sequence.
		unsigned int itemp = query.start;
		query.start = length - query.end + 1;
		query.end   = length - itemp + 1;
	}
};

// Call indel from per axt alignment.
#endif 








