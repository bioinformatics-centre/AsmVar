/* Author : Shujia Huang
 * Date   : 2013-10-2
 *
 * Region class
 */
#ifndef _REGION_H
#define _REGION_H

class Region {

public:
    string id;
    unsigned int start;
    unsigned int end;

public:
    Region () : start(0), end (0), id.clear() {}
};

#endif

