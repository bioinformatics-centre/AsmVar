#include "VarUnitiant.h"
#include <assert>

void AxtVar::CallInsertion () { 
// Actually, we just have to call  the target gap regions.	
// All the coordinate of query should be uniform to the positive strand!
	vector< VarUnit > gap = CallGap ( target, tarSeq, query, qrySeq, strand, "Ins" );
	for ( size_t i(0); i < gap.size(); ++i ) insertion.push_back( gap[i] );
}

void AxtVar::CallDeletion () { 
// Actually, we just have to call  the query gap regions.
// All the coordinate of query should be uniform to the positive strand!
	vector< VarUnit > gap = CallGap ( query, qrySeq, target, tarSeq, strand, "Del" );
	for ( size_t i(0); i < gap.size(); ++i ) deletion.push_back( gap[i] );
}

void AxtVar::CallIversion( MapReg left, MapReg middle, MapReg right ) {
	assert ( left.target.id == right.target.id  && left.query.id == right.query.id  );
	assert ( left.target.id == middle.target.id && left.query.id == middle.query.id );

	VarUnit reg;
    reg.type = "Inv";
	if ( left.strand == right.strand && middle.strand != left.strand ) {
    	reg.target = middle.target;
	    reg.query  = middle.query ;
    	reg.strand = middle.strand;
		inversion.push_back( reg );
	}
}

void AxtVar::CallNoSolution ( MapReg mapreg, string type ) {
	VarUnit reg;
	reg.target = mapreg.target;
	reg.query  = mapreg.query;
	reg.strand = mapreg.strand;
	reg.type   = type;      // No solution
	nosolution.push_back( reg );
}

void AxtVar::CallMapRegVar () { 
// Should be debug carfully here!
// All the coordinate of query should be uniform to the positive strand!

	map< size_t, vector<size_t> > mark;
	VarUnit simulgap;
	for ( map<string, vector<MapReg> >::iterator it( mapreg.begin() ); it != mapreg.end(); ++it ) {

		if ( it->second.size() < 2 ) continue;
		sort( it->second.begin(), it->second.end(), MySortByTar ); // Sort by the coordinate of target mapping positions
		mark = MakeClust( it->second );                            // mark different block

		if ( mark.size() == 1 ) {          // Just one order, so the coordinate orders are right! Sample case
			if ( it->second.size() > 2 ) { // More or equal three
				for ( size_t i(1); i < it->second.size() - 1; ++i ) {

					if ( it->second[i-1].strand == it->second[i].strand ) { 
						simulgap = CallGap( it->second[i-1], it->second[i] );
						simulreg.push_back( simulgap );
					}
					if ( it->second[i].strand == it->second[i+1].strand ) {
                        simulgap = CallGap( it->second[i], it->second[i+1] );
                        simulreg.push_back( simulgap );
                    }
					CallIversion ( it->second[i-1], it->second[i], it->second[i+1] );
				}
			} else {    // Just == 2
				if ( it->second[0].strand == it->second[1].strand ) {
					simulgap = CallGap( it->second[0], it->second[1] );
					simulreg.push_back( simulgap );
				} else {// different strand, but just 2 alignments, so No solution
					CallNoSolution( it->second[0], "Nos-strand" );
					CallNoSolution( it->second[1], "Nos-strand" );
				}
			}
		} else if ( mark.size() == 2 ) {
		} else if ( mark.size() == 3 ) {
		} else {
		}
	}
}

// friendship function in class 'AxtVar'
map< size_t, vector<size_t> > MakeClust ( vector<MapReg> & mapreg ) {

	map< size_t, vector<size_t> > mark;
	if ( mapreg.size() > 0 ) {

		size_t j (0), k(0) ;
		unsigned int prepos;
		for ( size_t i(0); i < mapreg.size(); ++i ) {
			
			if ( mark.count(k) && mark[k].size() >= 2 ){

				assert ( i >= 2 );
				j = i - 2; prepos = mapreg[j].query.start;
				for (; j >= 0 && prepos == mapreg[i-1].query.start; --j ) { prepos = mapreg[j].query.start; } // skip the equel value!
				if ( prepos < mapreg[i-1].query.start && mapreg[i].query.start < mapreg[i-1].query.start ) ++k;
				if ( prepos > mapreg[i-1].query.start && mapreg[i].query.start > mapreg[i-1].query.start ) ++k;
			}
			mark[k].push_back( i );
//Complete cluster, but we still need to Test here carefully!
		}
	}
	return mark;
}

vector< VarUnitUnit > CallGap ( Region & tar,    // chrM 16308 16389  or Contig102837 1 81
                                string & tarSeq, // Contig102837 1 81 or chrM 16308 16389
                                Region & qry,    // CATAGTACATAAAGTCATTTACCGTACATAGCACATTACAG
                                string & qrySeq, // CATAGTACATAAAGTCATTTACCGTACATAGCACATTACAG
                                char strand,     // + or -
                                string type )    // insertion or deletion
{
// This function is just used to call the gap regions of 'tar' (not for 'qry'!!). which will be indel actually ( indels are gaps ).
	assert ( tarSeq.length() == qrySeq.length() );

	VarUnit tmpgap; 
	tmpgap.target.id = tar.id;
	tmpgap.query.id  = qry.id;
	tmpgap.strand = strand; 
	tmpgap.type   = type;

	vector< VarUnit > gap;
	size_t i(0), j(0), tgaplen(0), qgaplen(0);
	while ( ( i = tarSeq.find_first_of('-',j) ) != string::npos ) {
	// I do have a program to debug this part at : /ifs1/ST_EPI/USER/huangshujia/bin/cpp_bin/learn_cpp/test_string.cpp
	// e.g. : tarSeq = "-ab-c-t--", 
	//        qrySeq = "aa-ccdcdt",
		for ( size_t k(j); k < i; ++k ) { if( qrySeq[k] == '-' ) ++qgaplen; }
		tmpgap.query.start = qry.start + i - qgaplen + 1; // Get the start position which in the tar-gap region.

		if ( ( j = tarSeq.find_first_not_of('-',i) ) == string::npos ) j = tarSeq.length();

		for ( size_t k(i); k < j; ++k ) { if( qrySeq[k] == '-' ) ++qgaplen; }
		tmpgap.query.end  = qry.start + j - qgaplen;      // Get the end  position which in the tar-gap region.

		tgaplen += ( j - i );
		tmpgap.target.start = tar.start + j - tgaplen - 1;
		tmpgap.target.end   = tmpgap.target.start;

		gap.push_back( tmpgap );
	};

	return gap;
}

VarUnit CallGap ( MapReg left, MapReg right ) { 
// Call the simultaneous gap between 'left' mapped region and the 'right' one
// 'left' and 'right' should be the same target id, the same query id and the same strand!
	assert ( left.target.id == right.target.id && left.query.id == right.query.id && left.strand == right.strand );

	VarUnit gap;
	gap.target.id = left.target.id;
	gap.query.id  = left.query.id ;
	gap.strand    = left.strand;

	gap.target.start = left.target.end;
	gap.target.end   = right.target.start;
	if ( left.query.start <= right.query.start ) {
		gap.query.start  = left.query.end;    // Should +1? what if the size larger than the size of query after +1. so I don't want to +1!
		gap.query.end    = right.query.start; // I don't want to -1 ! If left.query overlap with right.query, we will find gap.query.start >= gap.query.end
	} else {
		// I consider the '-' strand here!!
		gap.query.start = right.query.end;
		gap.query.end   = left.query.start;
	}

	bool isTarOvlp( false ), isQryOvlp( false );
	if ( gap.target.end <= gap.target.start ) {
		gap.target.start = left.target.start;
		gap.target.end   = right.target.end;
		isTarOvlp        = true;
	}
	if ( gap.query.end  <= gap.query.start ) {
		gap.query.start  = ( left.query.start <= right.query.start ) ? left.query.start : right.query.start;
		gap.query.end    = ( left.query.start <= right.query.start ) ? right.query.end  : left.query.end;
		isQryOvlp        = true;
	}

	if ( isTarOvlp && isQryOvlp ) { 
		gap.type = "gap-3";
	} else if ( isTarOvlp ) {
		gap.type = "gap-2";
	} else if ( isQryOvlp ) {
		gap.type = "gap-1";
	} else { // All not overlap
		gap.type = "gap-n"; // This gap means the normal simultaneous gaps
	}

	return gap;
}

inline bool MySortByTar ( MapReg i, MapReg j ) { return ( i.target.start < j.target.start ); }
inline bool MySortByQry ( MapReg i, MapReg j ) { return ( i.query.start  < j.query.start  ); }



