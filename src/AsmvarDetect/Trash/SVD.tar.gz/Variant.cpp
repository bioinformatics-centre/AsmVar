/* 
 * Author : Shujia Huang
 * Date   : 2013-10-2
 *
 */ 
#include <algorithm>
#include "Variant.h"
#include <stdlib.h>
#include <assert.h>

using namespace std;

// Used to calculate the 'n' length in class 'VarUnit' and 'AxtVar'
unsigned int NLength ( string & str ) {

	uint len(0);
	for ( size_t i(0); i < str.size(); ++i )
		if ( str[i] == 'N' || str[i] == 'n' ) ++len;

	return len;
}

void AxtVar::CallInsertion () { 
// Actually, we just have to call  the target gap regions.	
// All the coordinate of query should be uniform to the positive strand!
	vector< VarUnit > gap = CallGap ( target, tarSeq, query, qrySeq, strand, "Ins" );
	for ( size_t i(0); i < gap.size(); ++i ) { 

		if ( !qryfa.fa.count(query.id) ) err("Missing some query id or query id can't match!!!\nThe unmatch query(main): " + query.id);

		gap[i].ConvQryCoordinate( qryfa.fa[query.id].length() ); // coordinates uniform to the positive strand!
		insertion.push_back( gap[i] );
		summary["query-Intra-gap('N')"] += qryfa.Nlength( query.id, gap[i].query.start, gap[i].query.end );
	}
}

void AxtVar::CallDeletion () { 
// Actually, we just have to call  the query gap regions.
// All the coordinate of query should be uniform to the positive strand!
	vector< VarUnit > gap = CallGap ( query, qrySeq, target, tarSeq, strand, "Del" );
	for ( size_t i(0); i < gap.size(); ++i ) { 
		gap[i].Swap(); // Swap query and target region!
		if ( !qryfa.fa.count( query.id ) ) { err ("Missing some query id or query id can't match!!!\nThe unmatch query(main): "+query.id); } 
		gap[i].ConvQryCoordinate( qryfa.fa[query.id].length() ); // coordinates uniform to the positive strand!

		deletion.push_back( gap[i] );
		summary["query-Intra-gap('N')"] += qryfa.Nlength( query.id, gap[i].query.start, gap[i].query.end );
	}
}

bool AxtVar::CallIversion( MapReg left, MapReg middle, MapReg right ) {

	assert ( left.query.id == right.query.id && left.query.id == middle.query.id );

	bool flag(false);
	if ( left.target.id != right.target.id || left.target.id != middle.target.id ) return flag;

	unsigned int rStart = min ( left.target.start, right.target.start );
	unsigned int rEnd   = max ( left.target.end  , left.target.end    ); 
	if ( left.strand   != right.strand ||
		 middle.strand == left.strand  ||
		 middle.target.start < rStart  ||
		 middle.target.start > rEnd  ) return flag; // Just make sure the middle.target.start between [rStart,rEnd]

	flag = true;
	VarUnit reg;
    reg.type = "Inv";
    reg.target = middle.target;
	reg.query  = middle.query ;
    reg.strand = middle.strand;
	inversion.push_back( reg );

	return flag;
}

bool AxtVar::CallTranslocat ( MapReg left, MapReg middle, MapReg right ) {

	assert ( left.query.id == right.query.id && left.query.id  == middle.query.id );
	bool flag(false);
	// The target id should be the same of 'left' and 'right'
	if ( left.target.id != right.target.id ) return flag;

	unsigned int rStart = min ( left.target.start, right.target.start );
	unsigned int rEnd   = max ( left.target.end  , left.target.end    ); 

	// Do not overlap with 'left' or 'right'. And be the same strand on either side of the 'middle' region
	if ( left.strand != right.strand || (middle.target.start <= rEnd && middle.target.end >= rStart) ) return flag;

	flag = true;
	VarUnit reg, gap;

	gap = CallGap ( left, right );
	reg.exp_target = gap.target;

	reg.target = middle.target;
	reg.query  = middle.query ;
	reg.strand = middle.strand;
	reg.type   = ( middle.target.id == left.target.id ) ? "Trans-Intra" : "Trans-Inter";
	if ( middle.strand == left.strand ) {
		reg.type += "1";
	} else {
		reg.type += "2";
	}
	translocation.push_back( reg );

	return flag;
}

void AxtVar::GetMapReg () {

	// Call the query coverting function here to make the '-' strand coordinates of query be the same as '+' strand!
	ConvQryCoordinate(); // ConvQryCoordinate() is a memerber function of class 'Axt'

	MapReg mpI;
	mpI.target = target; mpI.query = query; mpI.strand = strand;
	mapreg[query.id].push_back( mpI ); // The 'key' is query.id

	maptar[target.id].push_back( target ); // stored the mapped target regions here
	mapqry[query.id].push_back ( query  ); // stored the mapped query  regions here

}

void AxtVar::CallSV () { // Call Stuctural variants, not indels!!! 
// Just use the memerber value 'mapreg' in this memerber function.
// Should be debug carfully here!
// All the coordinate of query should be uniform to the positive strand, then I can sort them!

	map< size_t, vector<size_t> > mark;
	VarUnit simulgap;
	for ( map<string, vector<MapReg> >::iterator it( mapreg.begin() ); it != mapreg.end(); ++it ) {
		if ( it->second.size() < 2 ) continue; // More than 2

		map<unsigned int, size_t> qry2tarOrder;
		sort( it->second.begin(), it->second.end(), MySortByTarM ); // Sort by the coordinate of target mapping positions
		for ( size_t i(0); i < it->second.size(); ++i ) { qry2tarOrder[it->second[i].query.start] = i; }
		sort( it->second.begin(), it->second.end(), MySortByQryM ); // Sort by the coordinate of query  mapping positions

		vector<MapReg> tmpreg;
		unsigned int pos1, pos2, pos;
		for ( size_t i(0); i < it->second.size(); ++i ) {

			pos = it->second[i].query.start;   // right (side)
			if ( tmpreg.size() == 1 ) {
				pos1 = tmpreg[0].query.start;
				if ( labs(qry2tarOrder[pos] - qry2tarOrder[pos1]) == 1 ) {
					// Regular simultaneous gap regions
					if ( CallSimultan(tmpreg[0], it->second[i]) ) tmpreg.clear();
				}
			} else if ( tmpreg.size() == 2 ) { // Candidate translocation or Candidate Inversion. It's not success when calling simultaneous gap
				pos1 = tmpreg[0].query.start;  // left 
				pos2 = tmpreg[1].query.start;  // middle
				if ( labs(qry2tarOrder[pos] - qry2tarOrder[pos1]) == 1 ) { // Means tmpreg[0] and tmpreg[1] are not the neighbour
					
					if ( CallTranslocat(tmpreg[0], tmpreg[1], it->second[i]) ) { 
						tmpreg.clear(); // Here 'tmpreg' just contain the two head element, in fact, I'm just clear the first and second elements.
					} else {
						tmpreg.erase( tmpreg.begin() );
						if ( labs(qry2tarOrder[pos] - qry2tarOrder[pos2]) == 1 ) { 
							if ( CallSimultan(tmpreg[0], it->second[i]) ) tmpreg.clear(); // Call simultaneous gap
						}
					}
				} else if( (labs(qry2tarOrder[pos2] - qry2tarOrder[pos1]) == 1) && (labs(qry2tarOrder[pos] - qry2tarOrder[pos2]) == 1) ){ 

					if ( CallIversion(tmpreg[0], tmpreg[1], it->second[i]) ) { 
						tmpreg.clear(); // Here 'tmpreg' just contain the two head element , in fact, I'm just clear the first and second elements.
					} else {
						tmpreg.erase ( tmpreg.begin() );
						if ( CallSimultan(tmpreg[0], it->second[i]) ) tmpreg.clear();
					}
				} else if (labs(qry2tarOrder[pos2] - qry2tarOrder[pos1]) == 1) { // No solution
					CallReg ( tmpreg[0], "Nos-JustNo", nosolution );
					tmpreg.erase ( tmpreg.begin() );
				} else {
					CallReg ( tmpreg[0], "Nos-Complex", nosolution );
					tmpreg.erase ( tmpreg.begin() );
				}
			} else if ( tmpreg.size() > 2 ) {
				cerr << "\n[ERROR] Program bugs! " << endl;
			}
			tmpreg.push_back( it->second[i] );
		}
		if ( tmpreg.size() == 2 ) {
			if ( CallSimultan ( tmpreg[0], tmpreg[1] ) ) {
				tmpreg.clear();
			} else if ( tmpreg[0].target.id == tmpreg[1].target.id ) { 
				CallReg ( tmpreg[0], "Nos-Strand", nosolution );
                CallReg ( tmpreg[1], "Nos-Strand", nosolution );
			} else { // Not in the same target
				CallReg ( tmpreg[0], "Nos-Complex", nosolution );
				CallReg ( tmpreg[1], "Nos-Complex", nosolution );
			}
		}
	}
}

bool AxtVar::CallSimultan ( MapReg left, MapReg right ) {

	bool success ( false );
	VarUnit simulgap;
	if ( left.target.id != right.target.id || left.strand != right.strand ) return success;	// (2013-10-20 19:17:40)

	simulgap = CallGap( left, right );
	simulreg.push_back( simulgap );
	success  = true;

	return success;
}

void AxtVar::CallReg ( MapReg mapreg, string type, vector< VarUnit > & varReg ) {
	VarUnit reg;
	reg.target = mapreg.target;
	reg.query  = mapreg.query;
	reg.strand = mapreg.strand;
	reg.type   = type;      // No solution
	varReg.push_back( reg );
}

void AxtVar::CallClipReg () {

	if ( qryfa.fa.empty() ) { cerr << "[WARNING] No Clip regions. Because the query fa is empty!" << endl; return; }
	VarUnit tmp;
	unsigned int rStart, rEnd;
	for ( map< string, vector<Region> >::iterator it( mapqry.begin() ); it != mapqry.end(); ++it ) {

		rStart = RegionMin( it->second );
		rEnd   = RegionMax( it->second );

		if ( rStart == 0 || rEnd == 0 ) { 

			cerr << "rStart == 0 || rEnd == 0" << "\nrStart: " << rStart << "\trEnd: " << rEnd << endl;
			for ( size_t i(0); i < it->second.size(); ++i )	
				cerr << "Size: " << it->second.size() << "\tit->second: " << it->second[i].id 
					 << "\t" << it->second[i].start   << "\t" << it->second[i].end << endl;
			exit(1);
		}

		if ( rStart == 1 && rEnd == qryfa.fa[it->first].length() ) summary["Full-Align"]++;

		tmp.query.id = it->first;
		tmp.strand   = '.';
		tmp.type     = "Clip";
		if ( rStart > 1 ) { tmp.query.start = 1; tmp.query.end = rStart - 1; clipreg.push_back( tmp ); }
		if ( rEnd   < qryfa.fa[it->first].length() ) {
			tmp.query.start = rEnd + 1;
			tmp.query.end   = qryfa.fa[it->first].length();
			clipreg.push_back( tmp );
		}
	}
	return;
}

void AxtVar::CallNomadic () {

	if ( qryfa.fa.empty() ) { cerr << "[WARNING] No Nomadic regions. Because the query fa is empty!" << endl; return; }
	VarUnit tmp;
	for ( map<string, string>::iterator it( qryfa.fa.begin() ); it != qryfa.fa.end(); ++it ) {

		if ( mapqry.count( it->first ) ) continue;
		tmp.query.id    = it->first;
		tmp.query.start = 1;
		tmp.query.end   = it->second.length();
		tmp.strand      = '.';
		tmp.type        = "Nomadic";
		nomadic.push_back( tmp );
	}
	return;
}

bool AxtVar::IsSameStrand ( vector<MapReg> & mapreg ) {

	bool same ( true );
	char strand = mapreg[0].strand;
	for ( size_t i(1); i < mapreg.size(); ++i ) {
		if ( strand != mapreg[i].strand ) { same = false; break; }
	}
	return same;
}

void AxtVar::Filter () {

	map< string,vector<Region> > mapNosolution;
	map<string, size_t> index;

	for ( size_t i(0); i < nosolution.size(); ++i ) mapNosolution[nosolution[i].query.id].push_back( nosolution[i].query );
	for ( map< string,vector<Region> >::iterator it( mapNosolution.begin() ); it != mapNosolution.end(); ++it ) {
		sort ( mapNosolution[it->first].begin(), mapNosolution[it->first].end(), SortRegion );
		index[it->first] = 0;
	}

	FilterReg ( mapNosolution, index, insertion ); // Filter insertion regions which in mapNosolution
	FilterReg ( mapNosolution, index, deletion  ); // Filter deletion  regions which in mapNosolution
	
	return;
}

void AxtVar::FilterReg( map< string,vector<Region> > tarregion, map<string, size_t> index, vector<VarUnit>& region ) {
// Just used in Filter() function

	if ( tarregion.empty() ) return;
	sort ( region.begin(), region.end(), MySortByQryV );	

	string key;
	bool flag;
	unsigned int prepos = region[0].query.start; 
	for ( size_t i(0); i < region.size(); ++i ) {

		if ( !index.count(key) ) continue;

		key = region[i].query.id;
		
		assert( prepos <= region[i].query.start ); // Chech sorted
		flag= true;

		for ( size_t j( index[key] ); j < tarregion[key].size(); ++j ) {
			if ( j > 0 ) assert( tarregion[key][j-1].start <= tarregion[key][j].start ); // Chech sorted
			if ( region[i].query.start > tarregion[key][j].end   ) continue;
			if ( region[i].query.end   < tarregion[key][j].start ) break;

			if ( flag ) { flag = false; index[key] = j; }
			region[i].Clear();
		}
	}
	return;
}

void AxtVar::Summary( string file ) {

	summary["Ins"]     = insertion.size();
	summary["Del"]     = deletion.size();
	summary["Inv"]     = inversion.size();
	summary["Clip"]    = clipreg.size();
	summary["Nomadic"] = nomadic.size();
	for ( size_t i(0); i < translocation.size(); ++i ) summary[translocation[i].type]++;
	for ( size_t i(0); i < nosolution.size();    ++i ) summary[nosolution[i].type]++;
	for ( size_t i(0); i < simulreg.size();      ++i ) summary[simulreg[i].type]++;

	map< string, unsigned int > tarCov, qryCov;
	map< string, vector<Region> >::iterator p( mapqry.begin() );
	for ( ; p != mapqry.end(); ++p ) { summary["qryCovlength"] += Covlength( p->second ); qryCov[p->first] += Covlength( p->second ); }
	p = maptar.begin();
	for ( ; p != maptar.end(); ++p ) { summary["tarCovlength"] += Covlength( p->second ); tarCov[p->first] += Covlength( p->second ); }

	ofstream O ( file.c_str() );
    if ( !O ) { cerr << "Cannot write to file : " << file << endl; exit(1); }
	for ( map<string, unsigned int>::iterator pt( summary.begin() ); pt!= summary.end(); ++pt ) {

		O << pt->first << "\t" << pt->second << endl;
	}
	O << "qryCovlength/querylength\t"  << double ( summary["qryCovlength"] ) / qryfa.length << endl;
	O << "tarCovlength/targetlength\t" << double ( summary["tarCovlength"] ) / tarfa.length << endl;
	O << "\n";
	for ( map<string, unsigned int>::iterator p(tarCov.begin()); p != tarCov.end(); ++p ) {

		double ratio = double(p->second)/tarfa.fa[p->first].length();
		O << "# " << p->first << "\t" << p->second << "/" << tarfa.fa[p->first].length() << "\t" << ratio << endl;
	}

	O.close();
}

void AxtVar::Output ( string file ) {

	ofstream O ( file.c_str() );
    if ( !O ) { cerr << "Cannot write to file : " << file << endl; exit(1); }

	Output ( insertion, O ); //
	Output ( deletion,  O ); //
	Output ( inversion, O );
	Output ( simulreg,  O ); //
	Output ( clipreg,   O ); //
	Output ( nomadic,       O ); //
	Output ( nosolution,    O );
	Output ( translocation, O );

	O.close();
	return;
}

void AxtVar::Output ( vector< VarUnit > & R, ofstream& O ) {

	for ( size_t i(0); i < R.size(); ++i ) {
		if ( R[i].Empty() ) continue;

		R[i].tarSeq = ( R[i].target.id == "-" ) ? "-" : tarfa.fa[R[i].target.id].substr(R[i].target.start - 1, R[i].target.end - R[i].target.start + 1);
		R[i].qrySeq = qryfa.fa[ R[i].query.id].substr( R[i].query.start - 1, R[i].query.end - R[i].query.start + 1 );

		if ( R[i].exp_target.isEmpty() ) {
			R[i].OutStd(  tarfa.fa[R[i].target.id].length(), qryfa.fa[ R[i].query.id].length(), O );
		} else {
			if ( R[i].exp_target.id.empty() || R[i].exp_target.id == "-" ) err ( "exp_target.id.empty() || R[i].exp_target.id == '-' " );
			R[i].exp_tarSeq = tarfa.fa[ R[i].exp_target.id ].substr( R[i].exp_target.start - 1, R[i].exp_target.end - R[i].exp_target.start + 1); 
			R[i].OutStd( tarfa.fa[R[i].target.id].length(), tarfa.fa[R[i].exp_target.id].length(), qryfa.fa[ R[i].query.id].length(), O);
		}
	}
}

void AxtVar::OutputGap( string file ) {
// The intra-gaps of scaffold are just the 'deletion' regions
// The inter-gaps between different scaffolds in the same chromosome need to calculate.
// Abort : 2013-11-04 13:20:30 !!!

	ofstream O ( file.c_str() );
	if ( !O ) { cerr << "Cannot write to file : " << file << endl; exit(1); }
	for ( size_t i(0); i < deletion.size(); ++i ) {
		if ( deletion[i].tarSeq.empty() || deletion[i].qrySeq.empty() ) { cerr << "tarSeq.empty() || qrySeq.empty()" << endl; exit(1); }
		
		unsigned int qnl = NLength ( deletion[i].qrySeq );
        unsigned int tnl = NLength ( deletion[i].tarSeq );
		unsigned int tarSeqLen = tarfa.fa[deletion[i].target.id].length();
		unsigned int qrySeqLen = qryfa.fa[deletion[i].query.id].length();
        O << deletion[i].target.id << "\t" << deletion[i].target.start << "\t" << deletion[i].target.end << "\t" 
          << deletion[i].target.end - deletion[i].target.start + 1     << "\t" << double(tnl)/deletion[i].tarSeq.length() << "\t" << tarSeqLen << "\t" 
          << deletion[i].query.id  << "\t" << deletion[i].query.start  << "\t" << deletion[i].query.end    << "\t" 
          << deletion[i].query.id  << "\t" << double(qnl)/deletion[i].qrySeq.length() << "\t" << qrySeqLen << "\t" 
          << deletion[i].strand    << "|"  << deletion[i].strand << "\tIntra-gap"     << endl;
	}

	map< string, vector<MapReg> > tarmapreg;
	for ( map<string, vector<MapReg> >::iterator it( mapreg.begin() ); it != mapreg.end(); ++it ) { // Reorder the keys to be target id
		for ( size_t i(0); i < it->second.size(); ++i ) { tarmapreg[it->second[i].target.id].push_back( it->second[i] ); }
	}
	for ( map<string, vector<MapReg> >::iterator it( mapreg.begin() ); it != mapreg.end(); ++it ) {

		sort( it->second.begin(), it->second.end(), MySortByTarM ); // Sort by the coordinate of target mapping positions
		for ( size_t i(0); i < it->second.size(); ++i ) {
		}
	}
	O.close();
}

// friendship function in class 'AxtVar'
unsigned int AxtVar::Covlength ( vector<Region> mapreg ) {

	if ( mapreg.empty() ) return 0;

	sort ( mapreg.begin(), mapreg.end(), SortRegion );
	unsigned int length(mapreg[0].end - mapreg[0].start + 1), prepos( mapreg[0].end );

	for ( size_t i(1); i < mapreg.size(); ++i ) {

		if ( mapreg[i].start > prepos ) {
			length += ( mapreg[i].end - mapreg[i].start + 1 );
			prepos = mapreg[i].end;
		} else if ( mapreg[i].end > prepos ) {
			length += ( mapreg[i].end - prepos );
			prepos = mapreg[i].end;
		} else {
			length += 0;
		}
	}
	
	return length;
}

vector< VarUnit > AxtVar::CallGap ( Region & tar,    // chrM 16308 16389  or Contig102837 1 81
                                    string & tarSeq, // Contig102837 1 81 or chrM 16308 16389
                                    Region & qry,    // CATAGTACATAAAGTCATTTACCGTACATAGCACATTACAG
                                    string & qrySeq, // CATAGTACATAAAGTCATTTACCGTACATAGCACATTACAG
                                    char   strand,   // + or -
                                    string type )    // insertion or deletion
{
// This function is just used to call the gap regions of 'tar' (not for 'qry'!!). which will be indel actually ( indels are gaps ).
	assert ( tarSeq.length() == qrySeq.length() );

	VarUnit tmpgap; 
	tmpgap.target.id = tar.id;
	tmpgap.query.id  = qry.id;
	tmpgap.strand = strand; 
	tmpgap.type   = type;

	vector< VarUnit > gap;
	size_t i(0), j(0), tgaplen(0), qgaplen(0);
	while ( ( i = tarSeq.find_first_of('-',j) ) != string::npos ) {
	// I do have a program to debug this part at : /ifs1/ST_EPI/USER/huangshujia/bin/cpp_bin/learn_cpp/test_string.cpp
	// e.g. : tarSeq = "-ab-c-t--", 
	//        qrySeq = "aa-ccdcdt",
		for ( size_t k(j); k < i; ++k ) { if( qrySeq[k] == '-' ) ++qgaplen; }
		tmpgap.query.start = qry.start + i - qgaplen; // Get the query start position which in the tar-gap region.

		if ( ( j = tarSeq.find_first_not_of('-',i) ) == string::npos ) j = tarSeq.length();
		for ( size_t k(i); k < j; ++k ) { if( qrySeq[k] == '-' ) ++qgaplen; }
		tmpgap.query.end  = qry.start + j - qgaplen - 1;      // Get the end  position which in the tar-gap region.

		tgaplen += ( j - i );
		tmpgap.target.start = tar.start + j - tgaplen - 1;
		tmpgap.target.end   = tmpgap.target.start;
		gap.push_back( tmpgap );
	};

	return gap;
}

VarUnit AxtVar::CallGap ( MapReg left, MapReg right ) { 
// Call the simultaneous gap between 'left' mapped region and the 'right' one
// 'left' and 'right' should be the same target id, the same query id and the same strand!
	assert ( left.target.id == right.target.id && left.query.id == right.query.id && left.strand == right.strand );

	VarUnit gap;
	gap.target.id = left.target.id;
	gap.query.id  = left.query.id ;
	gap.strand    = left.strand;

	gap.target.start = left.target.end;
	gap.target.end   = right.target.start;
	if ( left.query.start <= right.query.start ) { // Ascending
		gap.query.start  = left.query.end;    // Should +1? what if the size larger than the size of query after +1. so I don't want to +1!
		gap.query.end    = right.query.start; // I don't want to -1 ! If left.query overlap with right.query, we will find gap.query.start >= gap.query.end
	} else { // Decending I consider the '-' strand here!!
		gap.query.start = right.query.end;
		gap.query.end   = left.query.start;
	}

	bool isTarOvlp( false ), isQryOvlp( false );
	if ( gap.target.end <= gap.target.start ) {
		gap.target.start = min ( left.target.start, right.target.start );
		gap.target.end   = max ( left.target.end  , right.target.end   );
		isTarOvlp        = true;
	}
	if ( gap.query.end  <= gap.query.start ) {
		gap.query.start  = min ( left.query.start, right.query.start );
		gap.query.end    = max ( left.query.end  , right.query.end   );
		isQryOvlp        = true;
	}

	if ( isTarOvlp && isQryOvlp ) { 
		gap.type = "gap-3";
	} else if ( isTarOvlp ) {
		gap.type = "gap-2";
	} else if ( isQryOvlp ) {
		gap.type = "gap-1";
	} else { // All not overlap
		gap.type = "gap-n"; // This gap means the normal simultaneous gaps
	}

	return gap;
}

inline bool MySortByTarM ( MapReg  i, MapReg  j ) { 
	if ( i.target.id == j.target.id ) {
		return ( i.target.start < j.target.start ); 
	} else {
		return ( i.target.id <  j.target.id );
	}
}
inline bool MySortByQryM ( MapReg  i, MapReg  j ) { return ( i.query.start  < j.query.start  ); }
inline bool MySortByQryV ( VarUnit i, VarUnit j ) { return ( i.query.start  < j.query.start  ); }
inline bool SortRegion   ( Region  i, Region  j ) { return ( i.start < j.start  ); }

unsigned int RegionMin   ( vector<Region> & region ) {

	if ( region.empty() ) { cerr << "[ERROR] Region is empty, when you're calling RegionMin() function.\n"; exit(1); }
	unsigned int pos = region[0].start;
	for ( size_t i(0); i < region.size(); ++i ) { if (region[i].start < pos ) pos = region[i].start; }
	return pos;
}
unsigned int RegionMax   ( vector<Region> & region ) {

	if ( region.empty() ) { cerr << "[ERROR] Region is empty, when you're calling RegionMax() function.\n"; exit(1); }
	unsigned int pos = region[0].end;
	for ( size_t i(0); i < region.size(); ++i ) { if (region[i].end > pos ) pos = region[i].end; }
	return pos;
}



